<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Wel come to Online Exam</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
include("header.php");
include("database.php");
extract($_POST);

if(isset($submit))
{
    $mysqli = new mysqli("localhost", "root1", "n1-p74_vu*)GWrwb", "root1");
    if ($mysqli->connect_error) {
        die("Connection failed: ". $mysqli->connect_error);
    }
    $sql = "SELECT * FROM mst_user WHERE login='$loginid' AND pass='$pass'";
    $result = $mysqli->query($sql);
    if ($result->num_rows < 1) {
        $found="N";
    } else {
        $_SESSION['login']=$loginid;
    }
    $mysqli->close();
}
if (isset($_SESSION['login']))
{
    echo "<h1 class='style8' align=center>Wel come to Online Exam</h1>";
    echo '<table width="28%"  border="0" align="center">
  <tr>
    <td width="7%" height="65" valign="bottom"><img src="image/HLPBUTT2.JPG" width="50" height="50" align="middle"></td>
    <td width="93%" valign="bottom" bordercolor="#0000FF"> <a href="sublist.php" class="style4">Subject for Quiz </a></td>
  </tr>
  <tr>
    <td height="58" valign="bottom"><img src="image/DEGREE.JPG" width="43" height="43" align="absmiddle"></td>
    <td valign="bottom"> <a href="result.php" class="style4">Result </a></td>
  </tr>
</table>';
    exit;
}

?>
<!-- rest of your code -->